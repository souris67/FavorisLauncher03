# Favoris Launcher (Android)

Launcher Android minimal avec mode clair/sombre, recherche, grille d'applications et gestion de favoris.

## Construire l'APK
1. Ouvrir ce dossier dans Android Studio (version récente).
2. Laisser Gradle synchroniser.
3. Menu **Build > Build APK(s)**.
4. L'APK debug sera dans `app/build/outputs/apk/debug/`.

## Utilisation
Installez l'APK puis, sur Android, choisissez **Favoris Launcher** comme application d'accueil par défaut.
Dans l'écran « Toutes les apps », touchez une application pour l'ajouter ou la retirer des favoris. Dans « Favoris », touchez une icône pour lancer l'application.
Le bouton clair/sombre est mémorisé.

Note: `QUERY_ALL_PACKAGES` permet de lister les applications installées; vérifiez les exigences de distribution Google Play avant publication.
